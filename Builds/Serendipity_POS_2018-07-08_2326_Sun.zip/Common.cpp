/**
* Common Files
* WEEK 2
* @BryanSpeelman
*/

#include "common.h"
#include <string>

using namespace std;

	//Global Arrays
	string bookTitle[20], isbn[20], author[20], publisher[20], dateAdded[20];
	int qtyOnHand[20];
	double wholesale[20], retail[20];

	qtyOnHand[0] = 435;