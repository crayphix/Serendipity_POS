/*
* Class: CMSC226 CRN 44374
* Instructor: Grigoriy Grinberg
* Description: 7/8 update on rolling Bookstore project
* Due Date: 7/8
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any student.
Print your Name here: Bryan Speelman
*/

#ifndef _BOOKDATA_H
#define _BOOKDATA_H


class BookData {
private: 
    //Member Variables
	char bookTitle[51];
	char isbn[14];
	char author[31];
	char publisher[31];
    char dateAdded[11];
    int qtyOnHand;
    double wholesale;
    double retail;

public:
    //Default constructor
    BookData();
	
	//Overloaded constructor
	BookData(char newTitle[51], char newISBN[14], char newAuthor[31], char newPublisher[31], char newDateAdded[11], int newQtyOnHand, double newWholesale, double newRetail);

    // Destructor
    ~BookData();

    // Mutator Functions
    void setTitle(char*);
        //set book title

    void setISBN(char*);
        //set book ISBN

    void setAuthor(char*);
        //set book Author
        
    void setDateAdded(char*);
        //Set date Added

    void setPub(char*);
        //Set publisher

    void setQty(int);
        //Set inv qty
        
    void setWholesale(double);
        // set book Wholesale price
    
    void setRetail(double);
        // Set book retail price

    bool isEmpty();
        // Determines if book is empty

    void removeBook();
	
	char* getTitle();
        // Returns Title
    
    char* getISBN();
        // Returns ISBN
    
    char* getAuthor();
        // Returns Author

    char* getPublisher();
        // Returns Publisher
    
    char* getDateAdded();
        // Returns DateAdded
    
    int getQty();
        // Returns Qty
     
    double getWholesale();
        // Returns Wholesale
     
    double getRetail();
        // Returns Retail
    
    int* getQtyPtr();
        // Return pointer to quantity location
    
    double* getWholesalePtr();
        // Return pointer to wholesale location
    
    char* getDateAddedPtr();
        // Return pointer to date Added
    
    bool bookMatch(char*);
        // The function accepts a string as its argument and return true if the string is found in
        // the book title. If the string is not found in the book title, bookMatch should
        // return false.

    //friend class from BookInf
    friend class BookInf;


};

#endif