/*
* Class: CMSC226 CRN 44374
* Instructor: Grigoriy Grinberg
* Description: 7/1 update on rolling Bookstore project
* Due Date: 7/1
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any student.
Print your Name here: Bryan Speelman
*/

#ifndef _CASHIER_H
#define _CASHIER_H

extern int cashier();

#endif

