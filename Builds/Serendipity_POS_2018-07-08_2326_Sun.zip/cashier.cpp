/*
* Class: CMSC226 CRN 44374
* Instructor: Grigoriy Grinberg
* Description: 7/1 update on rolling Bookstore project
* Due Date: 7/1
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any student.
Print your Name here: Bryan Speelman
*/

#include <iostream>
#include <iomanip>
#include <string>
#include "cashier.h"
#include "mainmenu.h"
#include <cctype>
#include "bookData.h"
using namespace std;

//Declare Array of book objects *********************** Driver data stored at 0 and 1**************
extern class BookData book[SIZE];

int cashier() {
	//Declare outer loop variables
	int hold; // variable to hold choice to loop sales system
	char goAgain = NULL; // variable to hold choice to go again

	//Prompt user for sales input
	do
	{
		//*****inner Loop variables*******
		string date;
		char isbnIn[14];
		
		string qty; //variable to hold qty to sell. Is a string to verify input selection

		//sale total variables
		double price = 0;
		double tax = 0;
		double total = 0;
		double subtotal = 0;
		
		//Create pointer array to point to qty
		int *qtyptr = nullptr;
		qtyptr = new int [100];

		//Create array to hold index
		int *indexptr = nullptr;
		indexptr = new int[100];

		int loopCt = 0; // loop count to iterate for each item added to cart

		//Get date for transaction	
		cout << "\nPlease enter the date: "; 
		cin.ignore(); // Get date of sale
		getline(cin, date);

		//prompt input of books to sell
		do {
			cout << "\nPlease enter the ISBN #: ";
			cin.getline(isbnIn, 14); // Get ISBN #
			strUpper(isbnIn);
			
			//Look up ISBN number prompt re-entry if invalid
			int count = 0; //counter for verification loop
			do {
				for (int i = 0; i < SIZE; i++) {
					if (strcmp(isbnIn, book[i].getISBN()) == 0) {
						indexptr[loopCt] = i;
						break;
					}

					else if (i == SIZE - 1 && isbnIn != book[i].getISBN()) {
						cout << "\nISBN does not exist. Please try again (enter 0 to exit): ";
						cin.getline(isbnIn, 14);
						if (strcmp(isbnIn, "0") == 0)
							return 0;
					}
				} break;
			} while (strcmp(isbnIn, book[loopCt].getISBN()) != 0);


			
			//Prompt user for amount to sell 
			cout << "How many copies?: ";
			getline(cin, qty);
			while(!isNumber(qty)){ //verify input is a number 
				cout << "\nInvalid input! Please enter a quantity: ";
				cin.ignore(numeric_limits<streamsize>::max(), '\n'); //clear input
				cin >> qty;
			}

			//Confirm inventory and let user know if out of bounds
			while(atoi(qty.c_str()) > book[indexptr[loopCt]].getQty() || !isNumber(qty) ){
				cout << "\nNot enough copies available! Please enter a quantity up to " << book[indexptr[loopCt]].getQty() << ": ";
				getline(cin, qty);
			}
			qtyptr[loopCt] = atoi(qty.c_str()); //Assign qty to sell to array

			// prompt user to input more books
			cout << "\nDo you have more books to add? (Y/N): ";
			cin >> goAgain;
			//
			while (toupper(goAgain) != 'Y' && toupper(goAgain) != 'N') { //loop goAgain choice
				cout << "\nPlease enter Y or N: ";
				cin.ignore(numeric_limits<streamsize>::max(), '\n'); //clear input
				cin >> goAgain;
			}
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); //clear input

			loopCt++; // iterate loopCt
		} while (toupper(goAgain) != 'N');


			//Output Sales Slip
		cout << "\n\n_____________________________________________________________";
		cout << "\nSerendipity Booksellers\n\n";
		cout << "Date: " << date << "\n\n";
		cout << "Qty" << setw(7) << "ISBN" << setw(18) << "Title" << setw(23) << "Price" << setw(12) << "Total\n";
		cout << "_____________________________________________________________\n\n\n";
		cout << left << setprecision(2) << fixed;

		//Loop through array and output books to be sold 
		for(int i = 0; i < loopCt; i++ ){
			cout << setw(6) << qtyptr[i] << setw(17) << book[indexptr[i]].getISBN() << setw(23) << book[indexptr[i]].getTitle() << "$ " 
			<< setw(9) << book[indexptr[i]].getRetail() << "$ " << (book[indexptr[i]].getRetail() * qtyptr[i]) << endl << endl;
			
			// Accumulate totals
			subtotal += (book[indexptr[i]].getRetail() * qtyptr[i]);

			// Update inventory
 			book[indexptr[i]].setQty(book[indexptr[i]].getQty() - qtyptr[i]);
		}
			//finish total calculations
			tax = subtotal * .06;
			total = subtotal + tax;	

		//Output accumulated totals
		cout << right << setw(20) << "Subtotal" << setw(39) << "$ " << subtotal << endl;
		cout << right << setw(15) << "Tax" << setw(44) << "$ " << tax << endl;
		cout << right << setw(17) << "Total" << setw(42) << "$ " << total << endl << endl;
		cout << "Thank You for Shopping at Serendipity!\n\n";
		cout << "_____________________________________________________________\n\n\n";
		cout << "Enter 1 to enter another sale, Enter 2 to exit: ";
		cin >> hold;
		cin.ignore();

	//Delete memory and reinitialize pointers to null
	delete [] qtyptr;
	qtyptr = nullptr;
	
	delete [] indexptr;
	indexptr = nullptr; 
	
	} while (hold == 1);

	return 0;
}
