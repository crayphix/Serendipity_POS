/*
* Class: CMSC226 CRN 44374
* Instructor: Grigoriy Grinberg
* Description: 7/8 update on rolling Bookstore project
* Due Date: 7/8
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any student.
Print your Name here: Bryan Speelman
*/


#include <iostream>
#include <iomanip>
#include <string>
#include <iomanip>
#include "bookData.h"
#include "mainmenu.h"

using namespace std;

//Default constructor
BookData::BookData(){
	bookTitle[51] = NULL;
	isbn[14] = NULL;
	author[31] = NULL;
	publisher[31] = NULL;
    dateAdded[11] = NULL;
    qtyOnHand = NULL;
    wholesale = NULL;
    retail = NULL;
}

////Overload Constructor
BookData::BookData(char newTitle[51], char newISBN[14], char newAuthor[31],
	char newPublisher[31], char newDateAdded[11], int newQtyOnHand, 
	double newWholesale, double newRetail){

	strcpy_s(bookTitle, newTitle);
	strUpper(bookTitle);

	strcpy_s(isbn, newISBN);
	strUpper(isbn);

	strcpy_s(author, newAuthor);
	strUpper(author);

	strcpy_s(publisher, newPublisher);
	strUpper(publisher);
	
	strcpy_s(dateAdded, newDateAdded);
	strUpper(dateAdded);
   
   qtyOnHand = newQtyOnHand;
   wholesale = newWholesale;
   retail = newRetail;
}

BookData::~BookData(){}


// function that sets title of bookdata object
void BookData::setTitle (char *newTitle) {
	strcpy_s(bookTitle, newTitle);
	strUpper(bookTitle); // set title to uppercase
}


// function that sets ISBN of bookdata structure
void BookData::setISBN(char *newISBN) {
	strcpy_s(isbn, newISBN);
	strUpper(isbn); // set isbn to uppercase
}

// function that sets publisher of bookdata structure
void BookData::setAuthor(char *newAuthor) {
	strcpy_s(author, newAuthor);
	strUpper(author); // set author to uppercase
}

// function that sets date added of bookdata structure
void BookData::setDateAdded(char *newDateadded) {
	strcpy_s(dateAdded, newDateadded);
	strUpper(dateAdded); // set date added to uppercase{
}

// function that sets publisher of bookdata structure
void BookData::setPub(char *newPublisher) {
	strcpy_s(publisher, newPublisher);
	strUpper(publisher); // set title to uppercase
}

// function that sets quantity of bookdata structure
void BookData::setQty(int newQty) {
	qtyOnHand = newQty;
}

// function that sets wholesale price of bookdata structure
void BookData::setWholesale(double newWhole) {
	wholesale = newWhole;
}

// function that sets retail price of bookdata structure
void BookData::setRetail(double newRetail) {
	retail = newRetail;
}

// bool function that returns 1 if bookdata stuct is empyt 0 if otherwise
bool BookData::isEmpty() {
	if (bookTitle != 0)
		return 1;
	else
		return 0;
}

//function that removes book from inventory
void BookData::removeBook() {
	strcpy_s(bookTitle, "");
	strcpy_s(isbn, "");
}

// function that returns title of book
char* BookData::getTitle(){
	return bookTitle;
}

//function that returns isbn
char* BookData::getISBN(){
	return isbn;
}

//function that returns author
char* BookData::getAuthor(){
	return author;
}

//function that returns publisher
char* BookData::getPublisher(){
	return publisher;
}

//function that returns dateAdded
char* BookData::getDateAdded(){
	return dateAdded;
}

//function that returns qtyOnHand
int BookData::getQty(){
	return qtyOnHand;
}

//function that returns wholesale
double BookData::getWholesale(){
	return wholesale;
}

//function that returns retail
double BookData::getRetail(){
	return retail;
}

int* BookData::getQtyPtr(){
	return &qtyOnHand;
}

double* BookData::getWholesalePtr(){
	return &wholesale;
}

char* BookData::getDateAddedPtr(){
	return &dateAdded[0];
}

bool BookData::bookMatch(char* search){
	if(strstr(bookTitle, search))
		return true;
	else
		return false;
}