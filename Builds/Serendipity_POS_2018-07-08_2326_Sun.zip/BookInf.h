/*
* Class: CMSC226 CRN 44374
* Instructor: Grigoriy Grinberg
* Description: 7/8 update on rolling Bookstore project
* Due Date: 7/8
* I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any student.
Print your Name here: Bryan Speelman
*/

#ifndef _BOOKINF_H
#define _BOOKINF_H

class bookData; //forward Declaration of bookData class

class BookInf {
public:

int bookinfo(char bookTitle[51], char isbn[14], char author[31],
    char publisher[31], char dateAdded[11], int qtyOnHand, double wholesale, double retail);

int bookinfo(char bookTitle[51], char isbn[14], int qtyOnHand, double wholesale);

int bookinfo(char bookTitle[51], char isbn[14], double retail, int qtyOnHand);

int bookinfo(char bookTitle[51], char isbn[14], int qtyOnHand);

int bookinfo(char bookTitle[51], char isbn[14], char dateAdded[11], int qtyOnHand, double wholesale);

}

#endif